import ContentShimmer from 'react-content-shimmer'
const CommentBoxShimmer = () => {
  return (
    <div className="p-2 d-flex align-items-center w-100">
    <div className='w-100'>
    {/* <div className="d-flex align-items-center">
        <ContentShimmer size={{ height: 15  }}  />
       
      </div>
      <div className="d-flex justify-content-center mt-5">
        <ContentShimmer size={{ height: 85 }} rounded={"10px"} />
       
      </div>

      <div className="mt-2 d-flex justify-content-between w-100">
    <div className=" d-flex align-items-center " style={{width:"20%"}}>
        <ContentShimmer size={{ height: 50,  }} rounded="100%" />
        </div>
        <div className=" d-flex align-items-center w-100" style={{width:"60%"}}>
        <ContentShimmer size={{ height: 35  }} rounded="2rem" />
       
      </div>
        <div className=" d-flex align-items-center w-100" style={{width:"20%"}}>
        <ContentShimmer size={{ height: 35 }}  />
       
      </div>
      </div> */}
    </div>
   
  </div>
  )
};
export default CommentBoxShimmer;