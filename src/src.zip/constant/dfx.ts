export const IMAGE_MAX_WIDTH = 2048;
