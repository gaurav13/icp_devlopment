export const ONLY_ALPHABET=/^[a-zA-Z\s]+$/;
export const ONLY_ALPHANUMERIC=/^[a-zA-Z0-9\s]+$/;
export const EMAIL_VALIDATE=/^[-a-zA-Z0-9._]+@([a-zA-Z0-9-]+?\.)+[A-Za-z]+$/;
