export const PRIMARY_COLOR = '#007AFF';
export const SECONDARY_COLOR = '#D9EBFF';
